Dipnot — logo paketi / logo pack
==================================

TR
- Tek işaretler (logo*.svg/png, saydam zemin): her yanında işaret
  yüksekliğinin en az 1/6'sı kadar boşluk bırak.
- Birleşik varyantlar (logo-*-on-*.svg/png): boşluk içinde gelir,
  ek boşluk ekleme.
- En küçük boyut: 16 px (favicon), 20 px (satır içi), 40 px
  (bağımsız), 80 px (vitrin), 8 mm (baskı).
- Esnetme, döndürme, yeniden renklendirme, gölge/parıltı ekleme yok.
- Ayrıntılar: https://dipnot.app/marka-kitabi.html

EN
- Solo marks (logo*.svg/png, transparent): keep at least 1/6 of the
  mark's height clear on every side.
- Composed variants (logo-*-on-*.svg/png): clear space is built in;
  don't add more.
- Minimum size: 16 px (favicon), 20 px (inline), 40 px (standalone),
  80 px (display), 8 mm (print).
- No stretching, rotating, recoloring, shadows or glows.
- Details: https://dipnot.app/brand-book.html
